import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Home/Home.component';
import { AboutComponent } from './About/About.component';
import { BlogComponent } from './Blog/Blog.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './_guards/auth.guard';
import { DashBoardComponent } from './Admin/DashBoard/DashBoard.component';
import { SiteComponent } from './Site/Site.component';
import { AdminComponent } from './Admin/Admin.component';

const routes: Routes = [
  {
    path: '',
    component: SiteComponent,
    children: [
      { path: '', component: HomeComponent, pathMatch: 'full'},
      { path: 'about', component: AboutComponent },
      { path: 'blog', component: BlogComponent, data: {title: 'Blog Page'} }
      // { path: 'test/:id', component: AboutComponent }
    ]
  },
  {
    path: '',
    component: AdminComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'dashboard', component: DashBoardComponent }
      // { path: 'profile', component: ProfileComponent }
    ]
  },
  { path: 'login', component: LoginComponent, data: {title: 'login Page'} },
  // { path: '', component: HomeComponent,  data: {title: 'Home Page'} },
  // { path: 'about', component: AboutComponent, data: {title: 'About Page'} },
  // { path: 'blog', component: BlogComponent, data: {title: 'Blog Page'} },
  // {
  //   path: 'admin',
  //   component: DashBoardComponent,
  //   canActivate: [AuthGuard],
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
