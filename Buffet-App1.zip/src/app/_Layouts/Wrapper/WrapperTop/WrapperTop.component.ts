import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { HomeComponent } from 'src/app/Home/Home.component';

@Component({
  selector: 'app-WrapperTop',
  templateUrl: './WrapperTop.component.html',
  styleUrls: ['./WrapperTop.component.css']
})
export class WrapperTopComponent implements OnInit {


  
  constructor() { }


  ngOnInit() {
    
  }

}
