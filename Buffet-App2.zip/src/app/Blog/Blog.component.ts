import { Component, OnInit } from '@angular/core';
import { BlogListService } from '../_services/blogList.service';


@Component({
  selector: 'app-Blog',
  templateUrl: './Blog.component.html',
  styleUrls: ['./Blog.component.css']
})
export class BlogComponent implements OnInit {
  public blogList = [];
  public errorMsg;
  constructor(private blogListService: BlogListService) { }

  ngOnInit() {
    this.getBlogList();
  }
  getBlogList() {
    this.blogListService.getBlog()
    .subscribe(
      data =>
      this.blogList = data,
      error =>
      this.errorMsg = error);
    }
}
