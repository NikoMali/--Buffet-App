import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { HomeComponent } from 'src/app/Home/Home.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-WrapperTop',
  templateUrl: './WrapperTop.component.html',
  styleUrls: ['./WrapperTop.component.css']
})
export class WrapperTopComponent implements OnInit {


  constructor( private translate: TranslateService) { }


  ngOnInit() {
  }
  useLanguage(language: string) {
    this.translate.use(language);
    console.log(this.translate.currentLoader);
  }
}
