import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BlogList } from '../_models/blogList';

@Injectable({
  providedIn: 'root'
})
export class BlogListService {

private url = 'assets/Data/blogList.json';

constructor(private http: HttpClient) { }

getBlog(): Observable<BlogList[]> {
  return this.http.get<BlogList[]>(this.url);
}



}
